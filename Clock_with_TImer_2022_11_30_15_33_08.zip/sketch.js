var timeleft = 30;

var startTime = 0;
var currentTime = 0;

function setup() {
  createCanvas(400, 400);
 startTime = millis();


  var params = getURLParams();
  console.log(params);
  if (params.minute) {
    var min = params.minute;
    timeleft = min * 60;
  }

  var timer = select('#timer');
  timer.html(convertSeconds(timeleft - currentTime));

  var interval = setInterval(timeIt, 1000);

  function timeIt() {
    currentTime = floor((millis() - startTime) / 1000);
    timer.html(convertSeconds(timeleft - currentTime));
    if (currentTime == timeleft) {
      ding.play();
      clearInterval(interval);
      //counter = 0;
    }
  }}

function convertSeconds(s) {
  var min = floor(s / 60);
  var sec = s % 60;
  return nf(min, 2) + ':' + nf(sec, 2);
}

var ding;

function preload() {
  ding = loadSound("ding.mp3");
}


function draw() {
  background(225);
  stroke(20);
  noFill();
 beginShape();
bezier(120,20,50,40,60,100,195,200,250,260,50,50)//top left
  vertex(120,20)
  vertex(280,20)
  endShape(CLOSE)
bezier(280,20,350,40,350,100,205,200,-890,-800,-100,100)//top right
bezier(205,200,350,260,350,330,300,380,890,0,0,0) //bottom right
  vertex(120,20)
  vertex(350,20)
bezier(100,380,50,300,50,260,195,200,0,0,0,0)//bottom left
  vertex(120,380)//base
  vertex(300,380)//base
  endShape(CLOSE)
stroke(20, 10, 10);
   fill(150,20,30);
  rect(60,20,278,10,10,10) //top rect
 rect(60,380,278,10,10,10) //bottom rect
 

}