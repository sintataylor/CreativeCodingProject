var timeleft = 30;

var startTime = 0;
var currentTime = 0;

function setup() {
  createCanvas(400, 400);
 startTime = millis();


  var params = getURLParams();
  console.log(params);
  if (params.minute) {
    var min = params.minute;
    timeleft = min * 60;
  }

  var timer = select('#timer');
  timer.html(convertSeconds(timeleft - currentTime));

  var interval = setInterval(timeIt, 1000);

  function timeIt() {
    currentTime = floor((millis() - startTime) / 1000);
    timer.html(convertSeconds(timeleft - currentTime));
    if (currentTime == timeleft) {
      ding.play();
      clearInterval(interval);
      //counter = 0;
    }
  }}

function convertSeconds(s) {
  var min = floor(s / 60);
  var sec = s % 60;
  return nf(min, 2) + ':' + nf(sec, 2);
}

var ding;

function preload() {
  ding = loadSound("ding.mp3");
}


function draw() {
  background(225);
  stroke(20);
  noFill();
  //balls start
  fill(220,180,10)
  
  ellipse(200, 200, 5, 5); //line 1, 1 ball
  ellipse(194, 193, 5, 5);//line 2, 3 balls
    ellipse(200, 193, 5, 5);
      ellipse(206, 193, 5, 5);
  ellipse(186, 187, 5, 5);//line 3, 6 balls
    ellipse(192, 187, 5, 5);
    ellipse(198, 187, 5, 5);
    ellipse(204, 187, 5, 5);
    ellipse(210, 187, 5, 5);
    ellipse(216, 187, 5, 5);
   ellipse(179, 181, 5, 5);//line 4, 8 balls
   ellipse(185, 181, 5, 5);
  ellipse(191, 181, 5, 5);
  ellipse(197, 181, 5, 5);
  ellipse(203, 181, 5, 5);
  ellipse(209, 181, 5, 5);
  ellipse(215, 181, 5, 5);
  ellipse(221, 181, 5, 5);
  ellipse(173, 175, 5, 5);//line 5, 10 balls. total 28
  ellipse(179, 175, 5, 5);
  ellipse(185, 175, 5, 5);
  ellipse(191, 175, 5, 5);
   ellipse(197, 175, 5, 5);
  ellipse(203, 175, 5, 5);
  ellipse(209, 175, 5, 5);
  ellipse(215, 175, 5, 5);
  ellipse(221, 175, 5, 5);
  ellipse(227, 175, 5, 5);
  ellipse(233, 175, 5, 5);
  ellipse(167, 175, 5, 5);
  //hourglass starts
 noFill();
  beginShape();
bezier(120,20,50,40,60,100,195,200,250,260,50,50)//top left
  vertex(120,20)
  vertex(280,20)
  endShape(CLOSE)
bezier(280,20,350,40,350,100,205,200,-890,-800,-100,100)//top right
bezier(205,200,350,260,350,330,300,380,890,0,0,0) //bottom right
  vertex(120,20)
  vertex(350,20)
bezier(100,380,50,300,50,260,195,200,0,0,0,0)//bottom left
  vertex(120,380)//base
  vertex(300,380)//base
  endShape(CLOSE)
stroke(20, 10, 10);
   fill(150,20,30);
  rect(60,19,278,10,10,10) //top rect
 rect(60,379,278,10,10,10) //bottom rect
 

}