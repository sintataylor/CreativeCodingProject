function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  stroke(20);
  fill(320);
 beginShape();
  vertex(120, 20);
  vertex(280, 20);
  vertex(200, 200);
  endShape(CLOSE)
    fill(320);
   beginShape();
  vertex(120, 380);
  vertex(280, 380);
  vertex(200, 200);
endShape(CLOSE)
    fill(150);
stroke(20, 10, 10);
   fill(150,20,30);
   beginShape();
  bezier(100,20,200,-3,200,0,300,20)
  endShape(CLOSE)
  beginShape();
  bezier(100,380,200,403,200,400,300,380)
  endShape(CLOSE)
//line(85, 20, 10, 10);
//line(100, 90, 15, 80);
//stroke(0, 0, 0);
//bezier(210, 20, 10, 10, 90, 90, 50, 80);
  //bezier(30, 380, 390, 310, 390, 290,50, 80);
}