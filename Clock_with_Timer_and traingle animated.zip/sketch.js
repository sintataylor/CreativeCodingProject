var timeleft = 30;
let y=0
let x=0
let y1=0
let x1a=0
let x1b=0
let y2=0
let x2a=0
let x2b=0
let xe=200
let ye=200

var startTime = 0;
var currentTime = 0;

function setup() {
  createCanvas(400, 400);
 startTime = millis();
  frameRate(1.75);

  var params = getURLParams();
  console.log(params);
  if (params.minute) {
    var min = params.minute;
    timeleft = min * 60;
  }

  var timer = select('#timer');
  timer.html(convertSeconds(timeleft - currentTime));

  var interval = setInterval(timeIt, 1000);

  function timeIt() {
    currentTime = floor((millis() - startTime) / 1000);
    timer.html(convertSeconds(timeleft - currentTime));
    if (currentTime == timeleft) {
      ding.play();
      clearInterval(interval);
      //counter = 0;
    }
  }}

function convertSeconds(s) {
  var min = floor(s / 60);
  var sec = s % 60;
  return nf(min, 2) + ':' + nf(sec, 2);
}

var ding;

function preload() {
  ding = loadSound("ding.mp3");
}


function draw() {
  background(225);
  stroke(20);
   if (timeleft >0)
    ellipse(200, ye, 3, 3); 
  if(ye=>200 && ye!=0)
    ye++
  noFill();
  //balls start
  fill(220,180,10)
  noStroke();
 
//initial superior triangle
  noStroke();
  triangle(200, 202, x1a+140, y1+150, x1b+260, y1+150);
  //final superior triangle
  //triangle(x+200, y+200, x+200, y+200, x+200, y+200)
 //final inferior triangle 
  //triangle(200,y2+340,x2a+140,380,x2b+260,380)
  //initial inferior triangle 
  triangle(200,y2+380,x2a+200,380,x2b+200,380)

 // }
  //hourglass starts
 noFill();
 stroke(1);
  beginShape();
bezier(120,20,50,40,60,100,195,200,250,260,50,50)//top left
  vertex(120,20)
  vertex(280,20)
  endShape(CLOSE)
bezier(280,20,350,40,350,100,205,200,-890,-800,-100,100)//top right
bezier(205,200,350,260,350,330,300,380,890,0,0,0) //bottom right
  vertex(120,20)
  vertex(350,20)
bezier(100,380,50,300,50,260,195,200,0,0,0,0)//bottom left
  vertex(120,380)//base
  vertex(300,380)//base
  endShape(CLOSE)
stroke(20, 10, 10);
   fill(150,20,30);
  rect(60,19,278,10,10,10) //top rect
 rect(60,379,278,10,10,10) //bottom rect
 
if (timeleft >0 && y1!=50) //height of superior triangle animation
   y1++
    if(y1==50) {
        y1=50
      }
  if (timeleft >0 && y2!=-50) //height of inferior triangle animation
   y2--
    if(y2==-50) {
        y2=-50
      }
if (timeleft >0 && x1a!=50) //top left vertex animation
   x1a++
    if(x1a==50) {
        x1a=50
      }
if (timeleft >0 && x1b!=-50) //top right vertex animation
   x1b--
    if(x1b==-50) {
        x1b=-50
      }
  if (timeleft >0 && x2b!=50) //bottom right vertex animation
   x2b++
    if(x2b==50) {
        x2b=50
      }
  if (timeleft >0 && x2a!=-50) //bottom right vertex animation
   x2a--
    if(x2a==-50) {
        x2a=-50
      }
     }

  